#ifndef INIT_H
#define INIT_H


float average(float *array, const int cols)
{
	float av = 0;
           for ( int j = 0; j < cols; j++ )
	   {
	      av = av + array[j];
   	   }
	return av/cols;
}


float noise(const float sigma_phi)
{
   // gaussian noise with width sigma, centred on 0;
   float u1, u2, u_val;
   static float g1, g2;
   static int box_muller_switch = 0;
  
   if (box_muller_switch == 0)
   {
      u1 = 1.0f; u2 = 1.0f;
      do
      {
         u1 = 2.0f*(float)rand()/RAND_MAX - 1.0f;
         u2 = 2.0f*(float)rand()/RAND_MAX - 1.0f;
      } while( (u1*u1+u2*u2) > 1.0f );
    
      u_val = sigma_phi * sqrt((-2.0f*log(u1*u1 + u2*u2))/(u1*u1 + u2*u2));
      g1 = u_val * u1; //if (u1 >= 0.0f) g1 = - g1;
      g2 = u_val * u2; //if (u2 >= 0.0f) g2 = - g2;
      box_muller_switch++;
    	
      return g1;
   }
   else
   {
      box_muller_switch = 0;
      return g2;
   }
      
}

void correct_average(float *array,  const int cols, const float av_needed)
{
   // correct the average
   float av = average(array, cols);
   printf("av before: %lf \n", av);
	
      for ( int j = 0; j < cols; j++ )
      {
         array[j]  += (av_needed - av) ;
      }
 
   av = average(array, cols); printf("av after: %lf\n", av);
}



void init(float *array,  const int cols, const float value, const float sigma_height)
{ 
   srand ( time(NULL) ); // random seed 
   //srand(1234); // constant seed

      for ( int j = 0; j < cols; j++ )
      {
         array[j] = value + noise(sigma_height);
      }

   correct_average(array, cols, value);
 
}




#endif
