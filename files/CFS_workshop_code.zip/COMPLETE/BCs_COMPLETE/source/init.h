#ifndef INIT_H
#define INIT_H


float average(float *array, size_t width, const int rows, const int cols)
{
	float av = 0;
	for ( int i = 1; i < rows+1; i++ ) // skip over virtual row x=0
	{
           for ( int j = 0; j < cols; j++ )
	   {
	      av = av + array[i*cols + j];
   	   }
	}
	return av/( rows*cols );
}


float noise(const float sigma_phi)
{
   // gaussian noise with width sigma_phi, centred on 0;
   float u1, u2, u_val;
   static float g1, g2;
   static int box_muller_switch = 0;
  
   if (box_muller_switch == 0)
   {
      u1 = 1.0f; u2 = 1.0f;
      do
      {
         u1 = 2.0f*(float)rand()/RAND_MAX - 1.0f;
         u2 = 2.0f*(float)rand()/RAND_MAX - 1.0f;
      } while( (u1*u1+u2*u2) > 1.0f );
    
      u_val = sigma_phi * sqrt((-2.0f*log(u1*u1 + u2*u2))/(u1*u1 + u2*u2));
      g1 = u_val * u1; //if (u1 >= 0.0f) g1 = - g1;
      g2 = u_val * u2; //if (u2 >= 0.0f) g2 = - g2;
      box_muller_switch++;
    	
      if (g1 > +0.4) return +0.4;
      else if (g1 < -0.4) return -0.4;
      else return g1;
   }
   else
   {
      box_muller_switch = 0;
		
      if (g2 > +0.4) return +0.4;
      else if (g2 < -0.4) return -0.4;
      else return g2;
   }
      
  // white/flat noise centred on 0, max_amp = coef
  // return coef * (2.0*( (float)rand()/RAND_MAX - 0.5));
}

void correct_average(float *array, size_t width, const int rows, const int cols, const float av_needed)
{
   // correct the average
   float av = average(array, width, rows, cols);
   printf("av before: %lf \n", av);
	
   for ( int i = 1; i < rows+1; i++ ) // skip over virtual row x=0
   {
      for ( int j = 0; j < cols; j++ )
      {
	 array[i*cols + j] += (av_needed - av) ;
      }
   }
 
   av = average(array, width, rows, cols); printf("av after: %lf\n", av);
}

void init(float *array, size_t width, const int rows, const int cols, polymer polymer1)
{
   srand ( time(NULL) ); // random seed 
   //srand(1234); // constant seed

   for ( int i = 1; i < rows+1; i++ ) // skip over virtual row x=0
   {
      for ( int j = 0; j < cols; j++ )
      {
         array[i*cols + j] = polymer1.phi_av + noise(polymer1.sigma_phi);
      }
   }
   
   correct_average(array, width, rows, cols, polymer1.phi_av);
}


#endif
