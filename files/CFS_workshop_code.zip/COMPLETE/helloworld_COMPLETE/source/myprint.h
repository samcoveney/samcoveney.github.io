#ifndef MYPRINT_H
#define MYPRINT_H

void myprintfunc()
{
   printf("Hello, World!\n");
   return;
}


#endif   
